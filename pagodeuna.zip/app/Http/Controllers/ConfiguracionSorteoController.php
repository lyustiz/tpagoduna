<?php

namespace App\Http\Controllers;

use App\Models\ConfiguracionSorteo;
use App\Http\Requests\StoreConfiguracionSorteoRequest;
use App\Http\Requests\UpdateConfiguracionSorteoRequest;

class ConfiguracionSorteoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreConfiguracionSorteoRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ConfiguracionSorteo $configuracionSorteo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ConfiguracionSorteo $configuracionSorteo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateConfiguracionSorteoRequest $request, ConfiguracionSorteo $configuracionSorteo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ConfiguracionSorteo $configuracionSorteo)
    {
        //
    }
}
