<?php

namespace App\Http\Controllers;

use App\Models\JugadaSorteo;
use App\Http\Requests\StoreJugadaSorteoRequest;
use App\Http\Requests\UpdateJugadaSorteoRequest;

class JugadaSorteoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreJugadaSorteoRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(JugadaSorteo $jugadaSorteo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(JugadaSorteo $jugadaSorteo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateJugadaSorteoRequest $request, JugadaSorteo $jugadaSorteo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(JugadaSorteo $jugadaSorteo)
    {
        //
    }
}
