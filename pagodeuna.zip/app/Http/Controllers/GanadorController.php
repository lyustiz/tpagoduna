<?php

namespace App\Http\Controllers;

use App\Models\Ganador;
use App\Http\Requests\StoreGanadorRequest;
use App\Http\Requests\UpdateGanadorRequest;

class GanadorController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreGanadorRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Ganador $ganador)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Ganador $ganador)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateGanadorRequest $request, Ganador $ganador)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Ganador $ganador)
    {
        //
    }
}
