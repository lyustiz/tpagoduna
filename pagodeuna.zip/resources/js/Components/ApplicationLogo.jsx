import logo from '../../../public/images/logo.png';

export default function ApplicationLogo(props) {
    return (
        <img className="h-12 w-auto lg:h-12" src={logo} height={50} width={50} />
    );
}
